package com.employee.management.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.management.converter.EmployeeConverter;
import com.employee.management.dto.EmployeeDto;
import com.employee.management.entity.EmployeeEntity;
import com.employee.management.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private EmployeeConverter employeeConverter;
	
	// fetching all employees
	public List<EmployeeDto> getAllEmployees(){
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		List<EmployeeEntity> employeeEntityList = (List<EmployeeEntity>)employeeRepository.findAll();
		if(employeeEntityList.size() != 0) {
			for(EmployeeEntity entity: employeeEntityList)
			employeeDtoList.add(employeeConverter.toDto(entity));			
		}
		return employeeDtoList;
	}
	
	// fetching employee by id
	public EmployeeDto getEmployee(int id){
		Optional<EmployeeEntity> employeeEntity = employeeRepository.findById(id);
		if(employeeEntity != null) {
			return employeeConverter.toDto(employeeEntity.get());
		}
		return null;
	}
	
	// inserting employee
	public void addEmployee(EmployeeDto dto) {
		employeeRepository.save(employeeConverter.toEntity(dto));
	}
	
	// updating employee by id
	public void updateEmployee(EmployeeDto dto, int id){
		if(id == dto.getEmployeeId()) {
			employeeRepository.save(employeeConverter.toEntity(dto));
		}
	}
	
	// deleting all employees
	public void deleteAllEmployees(){
		employeeRepository.deleteAll();
	}
	
	// deleting employee by id
	public void deleteEmployeeByID(int id){
		employeeRepository.deleteById(id);
	}
}
