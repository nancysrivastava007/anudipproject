package com.employee.management.converter;

import com.employee.management.dto.DepartmentDto;
import com.employee.management.entity.DepartmentEntity;

public class DepartmentConverter {
	
	public DepartmentEntity toEntity(DepartmentDto dto) {
		return DepartmentEntity.builder()
				.departmentName(dto.getDepartmentName())
				.departmentDescription(dto.getDepartmentDescription())
				.build();		
	}
	
	public DepartmentDto toDto(DepartmentEntity entity) {
		return DepartmentDto.builder()
				.departmentName(entity.getDepartmentName())
				.departmentDescription(entity.getDepartmentDescription())
				.build();		
	}
}
