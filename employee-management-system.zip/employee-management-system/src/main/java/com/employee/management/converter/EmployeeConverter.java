package com.employee.management.converter;

import com.employee.management.dto.DepartmentDto;
import com.employee.management.dto.EmployeeDto;
import com.employee.management.entity.DepartmentEntity;
import com.employee.management.entity.EmployeeEntity;

public class EmployeeConverter {
	
	public EmployeeEntity toEntity(EmployeeDto dto) {
		return EmployeeEntity.builder()
				.firstName(dto.getFirstName())
				.lastName(dto.getLastName())
				.department(DepartmentEntity.builder()
						.departmentId(dto.getDepartment().getDepartmentId())
						.departmentName(dto.getDepartment().getDepartmentName())
						.departmentDescription(dto.getDepartment().getDepartmentDescription())
						.build())
				.build();		
	}
	
	public EmployeeDto toDto(EmployeeEntity entity) {
		return EmployeeDto.builder()
				.firstName(entity.getFirstName())
				.lastName(entity.getLastName())
				.department(DepartmentDto.builder()
						.departmentId(entity.getDepartment().getDepartmentId())
						.departmentName(entity.getDepartment().getDepartmentName())
						.departmentDescription(entity.getDepartment().getDepartmentDescription())
						.build())
				.build();		
	}
}
